[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/f6___mNy)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-7f7980b617ed060a017424585567c406b6ee15c891e84e1186181d67ecf80aa0.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=13312647)
# Exercise 12 - Blazor

* Seznamte se základními rozdíly mezi frontend frameworky Blazor a Angular, React, Vue - [What is Blazor vs (Angular, React, and Vue)](https://devathon.com/blog/blazor-vs-angular-vs-react-vs-vue/)
* Vyzkoušejte vytvořit jednoduchou Blazor Todo aplikaci - [Build a web app with Blazor](https://learn.microsoft.com/en-us/training/modules/build-blazor-webassembly-visual-studio-code/?WT.mc_id=dotnet-35129-website)
  * Pro přidání Blazor projektu do existujícího řešení Blazor.sln použijte příkaz - `dotnet sln add cesta-k-souboru-csproj`
