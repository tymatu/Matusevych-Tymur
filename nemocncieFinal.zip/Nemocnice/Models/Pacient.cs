﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Nemocnice.Models;

public class Pacient : INotifyPropertyChanged
{
    private string _jmeno;
    private string _prijmeni;
    private string _cisloPojisteni;
    private string _telCislo;
    private Adresa _adresa;
    private Lekar? _lekar;
    private Oddeleni _oddeleni;

    [Key]
    public int PacientId { get; set; }

    [Required(ErrorMessage = "Jmeno je povinne")]
    public string Jmeno
    {
        get { return _jmeno; }
        set
        {
            if (_jmeno != value)
            {
                _jmeno = value;
                OnPropertyChanged(nameof(Jmeno));
            }
        }
    }

    [Required(ErrorMessage = "Prijmeni je povinne")]
    public string Prijmeni
    {
        get { return _prijmeni; }
        set
        {
            if (_prijmeni != value)
            {
                _prijmeni = value;
                OnPropertyChanged(nameof(Prijmeni));
            }
        }
    }

    [Required(ErrorMessage = "Cislo pojisteni je povinne")]
    public string CisloPojisteni
    {
        get { return _cisloPojisteni; }
        set
        {
            if (_cisloPojisteni != value)
            {
                _cisloPojisteni = value;
                OnPropertyChanged(nameof(CisloPojisteni));
            }
        }
    }

    [RegularExpression(@"^\d{9}$", ErrorMessage = "Telefonni cislo musi byt devitimistne cislo.")]
    public string TelCislo
    {
        get { return _telCislo; }
        set
        {
            if (_telCislo != value)
            {
                _telCislo = value;
                OnPropertyChanged(nameof(TelCislo));
            }
        }
    }

    [ForeignKey("AdresaId")]
    
    public Adresa Adresa
    {
        get { return _adresa; }
        set
        {
            if (_adresa != value)
            {
                _adresa = value;
                OnPropertyChanged(nameof(Adresa));
            }
        }
    }
    
    public Oddeleni Oddeleni
    {
        get { return _oddeleni; }
        set
        {
            if (_oddeleni != value)
            {
                _oddeleni = value;
                OnPropertyChanged(nameof(Oddeleni));
            }
        }
    }
  //  [ForeignKey("LekarId")]
    public Lekar? Lekar
    {
        get { return _lekar; }
        set
        {
            if (_lekar != value)
            {
                _lekar = value;
                OnPropertyChanged(nameof(Lekar));
            }
        }
    }
    [ForeignKey("HealthCardId")]
    public HealthCard Card { get; set; }
    
    [Display(Name = "Analýzy")]
    [ForeignKey("AnalyzaId")]
    public virtual List<Analyza> Analyzy { get; set; } = new List<Analyza>();

    public event PropertyChangedEventHandler PropertyChanged;

    public override string ToString()
    {
        return Jmeno + " " + Prijmeni;
    }

    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}