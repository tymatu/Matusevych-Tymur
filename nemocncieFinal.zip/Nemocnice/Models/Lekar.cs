﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Nemocnice.Models;

public class Lekar : INotifyPropertyChanged
{
    private string _jmeno;
    private string _prijmeni;
    private Oddeleni _oddeleni;
    private string _telCislo;
    private Adresa _adresa;
    private User _userData;
    private Role _roleUser;

    public Lekar()
    {
    }

    public Lekar(string jmeno, string prijmeni, Oddeleni oddeleni, string telCislo, Adresa adresa, User userData)
    {
        _jmeno = jmeno;
        _prijmeni = prijmeni;
        _oddeleni = oddeleni;
        _telCislo = telCislo;
        _adresa = adresa;
        _userData = userData;
    }
    [Key]
    public int LekarId { get; set; }

    [Required(ErrorMessage = "Jmeno lekare je povinne")]
    public string Jmeno
    {
        get { return _jmeno; }
        set
        {
            if (_jmeno != value)
            {
                _jmeno = value;
                OnPropertyChanged(nameof(Jmeno));
            }
        }
    }

    [Required(ErrorMessage = "Prijmeni lekare je povinne")]
    public string Prijmeni
    {
        get { return _prijmeni; }
        set
        {
            if (_prijmeni != value)
            {
                _prijmeni = value;
                OnPropertyChanged(nameof(Prijmeni));
            }
        }
    }

    [Required(ErrorMessage = "Oddeleni je povinne")]
    public Oddeleni Oddeleni
    {
        get { return _oddeleni; }
        set
        {
            if (_oddeleni != value)
            {
                _oddeleni = value;
                OnPropertyChanged(nameof(Oddeleni));
            }
        }
    }

    [RegularExpression(@"^\d{9}$", ErrorMessage = "Telefonni cislo musi byt devitimistne cislo.")]
    public string TelCislo
    {
        get { return _telCislo; }
        set
        {
            if (_telCislo != value)
            {
                _telCislo = value;
                OnPropertyChanged(nameof(TelCislo));
            }
        }
    }
    
    [ForeignKey("AdresaId")]
    public Adresa Adresa
    {
        get { return _adresa; }
        set
        {
            if (_adresa != value)
            {
                _adresa = value;
                OnPropertyChanged(nameof(Adresa));
            }
        }
    }
    
    [ForeignKey("UserId")]
    public User UserData
    {
        get { return _userData; }
        set
        {
            if (_userData != value)
            {
                _userData = value;
                OnPropertyChanged(nameof(UserData));
            }
        }
    }
    
    public Role RoleUser
    {
        get { return _roleUser; }
        set
        {
            if (_roleUser != value)
            {
                _roleUser = value;
                OnPropertyChanged(nameof(RoleUser));
            }
        }
    }

    public List<Pacient> Pacienty { get; set; } = new List<Pacient>();

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}