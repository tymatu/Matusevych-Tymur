﻿namespace Nemocnice.Models;

public enum Role
{
    LEKAR,ADMIN
}