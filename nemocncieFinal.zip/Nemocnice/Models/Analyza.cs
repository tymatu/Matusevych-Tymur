﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Nemocnice.Models;

using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

public class Analyza : INotifyPropertyChanged
{
    private DateTime _datumAnalyzy;
    private string _vysledek;

    public Analyza(DateTime datumAnalyzy, string vysledek, Pacient pacient)
    {
        _datumAnalyzy = datumAnalyzy;
        _vysledek = vysledek;
        Pacient = pacient;
    }

    public Analyza()
    {
    }

    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int AnalyzaId { get; set; }

    [Display(Name = "Datum Analýzy")]
    [Required(ErrorMessage = "Datum analýzy je povinné")]
    public DateTime DatumAnalyzy
    {
        get { return _datumAnalyzy; }
        set
        {
            if (_datumAnalyzy != value)
            {
                _datumAnalyzy = value;
                OnPropertyChanged(nameof(DatumAnalyzy));
            }
        }
    }

    [Display(Name = "Výsledek")]
    public string Vysledek
    {
        get { return _vysledek; }
        set
        {
            if (_vysledek != value)
            {
                _vysledek = value;
                OnPropertyChanged(nameof(Vysledek));
            }
        }
    }
        
    [ForeignKey("PacientId")]
    public virtual Pacient Pacient { get; set; }

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}