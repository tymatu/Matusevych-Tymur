﻿namespace Nemocnice.Models;

public enum Oddeleni
{
    ALL,
    Chirurgie,
    Interni,
    Neurologie,
    Oftalmologie,
    Pediatrie
    
}