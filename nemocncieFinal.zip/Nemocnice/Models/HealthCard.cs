﻿namespace Nemocnice.Models;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class HealthCard : INotifyPropertyChanged
{
    private DateTime _datumPrijeti;
    private string _diagnoza;
    private string _symptomy;
    private string _zaloby;
    private string _zakluceni;
    private List<Analyza> _analyzy;

    [Key]
    public int HealthCardId { get; set; }

    [Display(Name = "Datum Přijetí")]
    [Required(ErrorMessage = "Datum přijetí je povinné")]
    public DateTime DatumPrijeti
    {
        get { return _datumPrijeti; }
        set
        {
            if (_datumPrijeti != value)
            {
                _datumPrijeti = value;
                OnPropertyChanged(nameof(DatumPrijeti));
            }
        }
    }

    [Display(Name = "Diagnóza")]
    [Required(ErrorMessage = "Diagnóza je povinná")]
    public string Diagnoza
    {
        get { return _diagnoza; }
        set
        {
            if (_diagnoza != value)
            {
                _diagnoza = value;
                OnPropertyChanged(nameof(Diagnoza));
            }
        }
    }

    [Display(Name = "Symptomy")]
    public string Symptomy
    {
        get { return _symptomy; }
        set
        {
            if (_symptomy != value)
            {
                _symptomy = value;
                OnPropertyChanged(nameof(Symptomy));
            }
        }
    }

    [Display(Name = "Žaloby")]
    public string Zaloby
    {
        get { return _zaloby; }
        set
        {
            if (_zaloby != value)
            {
                _zaloby = value;
                OnPropertyChanged(nameof(Zaloby));
            }
        }
    }

    [Display(Name = "Závěr")]
    public string Zaver
    {
        get { return _zakluceni; }
        set
        {
            if (_zakluceni != value)
            {
                _zakluceni = value;
                OnPropertyChanged(nameof(Zaver));
            }
        }
    }

    
    

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}