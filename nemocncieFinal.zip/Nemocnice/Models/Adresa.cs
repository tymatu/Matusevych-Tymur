﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Nemocnice.Models;

public class Adresa : INotifyPropertyChanged
{
    private int _adresaId;
    private string _ulice;
    private string _mesto;
    private string _psc;
    private string? _cp;
    private string? _co;

    public Adresa()
    {
    }

    [Key]
    public int AdresaId 
    {
        get { return _adresaId; }
        set
        {
            if (_adresaId != value)
            {
                _adresaId = value;
                OnPropertyChanged(nameof(AdresaId));
            }
        }
    }

    [Required(ErrorMessage = "Ulice je povinna")]
    public string Ulice
    {
        get { return _ulice; }
        set
        {
            if (_ulice != value)
            {
                _ulice = value;
                OnPropertyChanged(nameof(Ulice));
            }
        }
    }

    [Required(ErrorMessage = "Mesto je povinne")]
    public string Mesto
    {
        get { return _mesto; }
        set
        {
            if (_mesto != value)
            {
                _mesto = value;
                OnPropertyChanged(nameof(Mesto));
            }
        }
    }

    [Required(ErrorMessage = "PSC je povinne")]
    [RegularExpression(@"^\d{5}$", ErrorMessage = "PSC musi byt petimistne cislo.")]
    public string PSC
    {
        get { return _psc; }
        set
        {
            if (_psc != value)
            {
                _psc = value;
                OnPropertyChanged(nameof(PSC));
            }
        }
    }
    
    public string? CP
    {
        get { return _cp; }
        set
        {
            if (_cp != value)
            {
                _cp = value;
                OnPropertyChanged(nameof(CP));
            }
        }
    }

    public string? CO
    {
        get { return _co; }
        set
        {
            if (_co != value)
            {
                _co = value;
                OnPropertyChanged(nameof(CO));
            }
        }
    }
    //public Lekar Lekar { get; set; }  // Navigation property
    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}