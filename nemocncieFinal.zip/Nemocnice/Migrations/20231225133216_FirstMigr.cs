﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Nemocnice.Migrations
{
    /// <inheritdoc />
    public partial class FirstMigr : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Adresy",
                columns: table => new
                {
                    AdresaId = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Ulice = table.Column<string>(type: "TEXT", nullable: false),
                    Mesto = table.Column<string>(type: "TEXT", nullable: false),
                    PSC = table.Column<string>(type: "TEXT", nullable: false),
                    CP = table.Column<string>(type: "TEXT", nullable: true),
                    CO = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Adresy", x => x.AdresaId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    UserName = table.Column<string>(type: "TEXT", maxLength: 50, nullable: false),
                    Password = table.Column<string>(type: "TEXT", maxLength: 100, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "Lekar",
                columns: table => new
                {
                    LekarId = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Jmeno = table.Column<string>(type: "TEXT", nullable: false),
                    Prijmeni = table.Column<string>(type: "TEXT", nullable: false),
                    Oddeleni = table.Column<int>(type: "INTEGER", nullable: false),
                    TelCislo = table.Column<string>(type: "TEXT", nullable: false),
                    AdresaId = table.Column<int>(type: "INTEGER", nullable: false),
                    UserId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Lekar", x => x.LekarId);
                    table.ForeignKey(
                        name: "FK_Lekar_Adresy_AdresaId",
                        column: x => x.AdresaId,
                        principalTable: "Adresy",
                        principalColumn: "AdresaId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Lekar_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Pacienti",
                columns: table => new
                {
                    PacientId = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Jmeno = table.Column<string>(type: "TEXT", nullable: false),
                    Prijmeni = table.Column<string>(type: "TEXT", nullable: false),
                    CisloPojisteni = table.Column<string>(type: "TEXT", nullable: false),
                    TelCislo = table.Column<string>(type: "TEXT", nullable: false),
                    AdresaId = table.Column<int>(type: "INTEGER", nullable: false),
                    LekarId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pacienti", x => x.PacientId);
                    table.ForeignKey(
                        name: "FK_Pacienti_Adresy_AdresaId",
                        column: x => x.AdresaId,
                        principalTable: "Adresy",
                        principalColumn: "AdresaId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Pacienti_Lekar_LekarId",
                        column: x => x.LekarId,
                        principalTable: "Lekar",
                        principalColumn: "LekarId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Lekar_AdresaId",
                table: "Lekar",
                column: "AdresaId");

            migrationBuilder.CreateIndex(
                name: "IX_Lekar_UserId",
                table: "Lekar",
                column: "UserId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Pacienti_AdresaId",
                table: "Pacienti",
                column: "AdresaId");

            migrationBuilder.CreateIndex(
                name: "IX_Pacienti_LekarId",
                table: "Pacienti",
                column: "LekarId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Pacienti");

            migrationBuilder.DropTable(
                name: "Lekar");

            migrationBuilder.DropTable(
                name: "Adresy");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
