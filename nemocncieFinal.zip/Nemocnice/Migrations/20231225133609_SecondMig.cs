﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Nemocnice.Migrations
{
    /// <inheritdoc />
    public partial class SecondMig : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Lekar_Adresy_AdresaId",
                table: "Lekar");

            migrationBuilder.DropForeignKey(
                name: "FK_Lekar_Users_UserId",
                table: "Lekar");

            migrationBuilder.DropForeignKey(
                name: "FK_Pacienti_Lekar_LekarId",
                table: "Pacienti");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Lekar",
                table: "Lekar");

            migrationBuilder.RenameTable(
                name: "Lekar",
                newName: "Lekari");

            migrationBuilder.RenameIndex(
                name: "IX_Lekar_UserId",
                table: "Lekari",
                newName: "IX_Lekari_UserId");

            migrationBuilder.RenameIndex(
                name: "IX_Lekar_AdresaId",
                table: "Lekari",
                newName: "IX_Lekari_AdresaId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Lekari",
                table: "Lekari",
                column: "LekarId");

            migrationBuilder.AddForeignKey(
                name: "FK_Lekari_Adresy_AdresaId",
                table: "Lekari",
                column: "AdresaId",
                principalTable: "Adresy",
                principalColumn: "AdresaId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Lekari_Users_UserId",
                table: "Lekari",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Pacienti_Lekari_LekarId",
                table: "Pacienti",
                column: "LekarId",
                principalTable: "Lekari",
                principalColumn: "LekarId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Lekari_Adresy_AdresaId",
                table: "Lekari");

            migrationBuilder.DropForeignKey(
                name: "FK_Lekari_Users_UserId",
                table: "Lekari");

            migrationBuilder.DropForeignKey(
                name: "FK_Pacienti_Lekari_LekarId",
                table: "Pacienti");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Lekari",
                table: "Lekari");

            migrationBuilder.RenameTable(
                name: "Lekari",
                newName: "Lekar");

            migrationBuilder.RenameIndex(
                name: "IX_Lekari_UserId",
                table: "Lekar",
                newName: "IX_Lekar_UserId");

            migrationBuilder.RenameIndex(
                name: "IX_Lekari_AdresaId",
                table: "Lekar",
                newName: "IX_Lekar_AdresaId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Lekar",
                table: "Lekar",
                column: "LekarId");

            migrationBuilder.AddForeignKey(
                name: "FK_Lekar_Adresy_AdresaId",
                table: "Lekar",
                column: "AdresaId",
                principalTable: "Adresy",
                principalColumn: "AdresaId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Lekar_Users_UserId",
                table: "Lekar",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Pacienti_Lekar_LekarId",
                table: "Pacienti",
                column: "LekarId",
                principalTable: "Lekar",
                principalColumn: "LekarId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
