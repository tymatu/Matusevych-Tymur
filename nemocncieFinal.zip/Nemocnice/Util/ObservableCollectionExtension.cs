﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Nemocnice.Util;

public static class ObservableCollectionExtension
{
    public static ObservableCollection<T> ToObservableCollection<T>(this IEnumerable<T> enumeration)
    {
        return new ObservableCollection<T>(enumeration);
    }
}