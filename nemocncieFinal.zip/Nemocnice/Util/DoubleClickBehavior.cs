﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Nemocnice.Util;

public static class DoubleClickBehavior
{
    public static readonly DependencyProperty DoubleClickCommandProperty =
        DependencyProperty.RegisterAttached(
            "DoubleClickCommand",
            typeof(ICommand),
            typeof(DoubleClickBehavior),
            new PropertyMetadata(null, OnDoubleClickCommandChanged));

    public static ICommand GetDoubleClickCommand(DependencyObject obj)
    {
        return (ICommand)obj.GetValue(DoubleClickCommandProperty);
    }

    public static void SetDoubleClickCommand(DependencyObject obj, ICommand value)
    {
        obj.SetValue(DoubleClickCommandProperty, value);
    }

    private static void OnDoubleClickCommandChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is Control control)
        {
            control.MouseDoubleClick -= Control_MouseDoubleClick;
            control.MouseDoubleClick += Control_MouseDoubleClick;
        }
    }

    private static void Control_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (sender is Control control)
        {
            ICommand command = GetDoubleClickCommand(control);
            if (command?.CanExecute(null) == true)
            {
                command.Execute(null);
            }
        }
    }
}