﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Nemocnice.Configuration;
using Nemocnice.Models;

namespace Nemocnice.Repositories;

public class LekarRep
{
    private readonly DbConfig db;

    public LekarRep(DbConfig db)
    {
        this.db = db;
    }

    public async Task<List<Lekar>> GetAllLekari(Oddeleni? oddeleni = null)
    {
        if (oddeleni != null && oddeleni != Oddeleni.ALL)
        {
            return await db.Lekari.Include(p=>p.Pacienty)
                .Include(p=>p.Adresa).Where(l => l.Oddeleni == oddeleni).ToListAsync();
        }
        return await db.Lekari.Include(p=>p.Pacienty)
            .Include(p=>p.Adresa).ToListAsync();
    }
    public async Task<List<Lekar>> GetAllLekariByFilter(string filter, Oddeleni? oddeleni = null)
    {
        IQueryable<Lekar> query = db.Lekari.Include(p => p.Pacienty)
            .Include(p => p.Adresa);

        if (oddeleni != null && oddeleni != Oddeleni.ALL)
        {
            query = query.Where(l => l.Oddeleni == oddeleni);
        }

        return  query.AsEnumerable()
            .Where(p => p.Jmeno.Contains(filter, StringComparison.OrdinalIgnoreCase) ||
                        p.Prijmeni.Contains(filter, StringComparison.OrdinalIgnoreCase))
            .ToList();
    }

    public async Task<List<Pacient>> GetAllPAcientyByLekar(Lekar lekar)
    {
        return await db.Pacienti.Include(p=>p.Lekar).Where(p => p.Lekar != null && p.Lekar.LekarId == lekar.LekarId).ToListAsync();
    }
    public async Task Update(Lekar lekar)
    {
        var existingPacient = await db.Pacienti.FindAsync(lekar.LekarId);

        if (existingPacient != null)
        {
            db.Entry(existingPacient).CurrentValues.SetValues(lekar);
        }

        await db.SaveChangesAsync();
    }
    public void Remove(Lekar lekar)
    {
        db.Lekari.Remove(lekar);
        db.SaveChanges();
    }
    public void Save(Lekar lekar)
    {
       
        db.Lekari.Add(lekar);
        db.SaveChanges();
        
        
    }

}