﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Nemocnice.Configuration;
using Nemocnice.Models;

namespace Nemocnice.Repositories;

public class PacientRep
{
    private readonly DbConfig db;

    public PacientRep(DbConfig db)
    {
        this.db = db;
    }

    public async Task<Pacient?> GetPacById(int id)
    {
        return await db.Pacienti
            .Include(p => p.Lekar)
            .Include(p => p.Card)
            .Include(p => p.Adresa)
            .Include(p=>p.Analyzy)
            .Where(pac=>pac.PacientId==id).FirstOrDefaultAsync();
    }

    public async Task<List<Pacient>> getAllPacients(Lekar? lekar = null)
    {
        if (lekar != null)
        {
            return await db.Pacienti.Where(p=>p.Lekar.LekarId==lekar.LekarId).Include(p=>p.Analyzy).Include(p => p.Adresa).Include(p => p.Lekar).ToListAsync();

        }
        return await db.Pacienti.Include(p => p.Adresa).Include(p => p.Lekar).ToListAsync();
    }

    public async Task<List<Pacient>> getAllPacientsByOddeleni(Oddeleni od, Lekar? lekar = null)
    {
        var query = db.Pacienti.Include(p=>p.Analyzy).Include(p => p.Adresa).Include(p => p.Lekar).Where(p => p.Oddeleni == od);

        if (od == Oddeleni.ALL)
        {
            return await getAllPacients(lekar);
        }

        if (lekar != null)
        {
            query = query.Where(l => l.Lekar != null && l.Lekar.LekarId == lekar.LekarId);
        }

        return await query.ToListAsync();
    }

    public async Task<List<Pacient>> GetAllPacientsByOddeleniAndFilter(Oddeleni od, string filter, Lekar? lekar = null)
    {
        var pacients = await getAllPacientsByOddeleni(od, lekar);

        return pacients
            .Where(p =>
                (lekar == null || p.Lekar?.LekarId == lekar.LekarId) &&
                (string.IsNullOrWhiteSpace(filter) ||
                 p.Jmeno.Contains(filter, StringComparison.OrdinalIgnoreCase) ||
                 p.Prijmeni.Contains(filter, StringComparison.OrdinalIgnoreCase)))
            .ToList();
    }

    public async Task<Lekar?> getLekarWithPatients(Lekar lekar)
    {
        return await db.Lekari.Where(l => l.LekarId == lekar.LekarId).Include(l => l.Pacienty).FirstOrDefaultAsync();
    }

    public async Task Update(Pacient pacient)
    {
        var existingPacient = await db.Pacienti.FindAsync(pacient.PacientId);

        if (existingPacient != null)
        {
            db.Entry(existingPacient).CurrentValues.SetValues(pacient);
        }

        await db.SaveChangesAsync();
    }
    public void Save(Pacient pacient)
    {
        if (pacient.Lekar != null)
        {
            Lekar? lek = db.Lekari.FirstOrDefault(l1 => l1.LekarId == pacient.Lekar.LekarId);
            pacient.Lekar = lek;
        }
        db.Pacienti.Add(pacient);
        db.SaveChanges();
    }
    public void Remove(Pacient pacient)
    {
        db.Pacienti.Remove(pacient);
        db.SaveChanges();
    }

}