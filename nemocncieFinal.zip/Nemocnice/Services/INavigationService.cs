﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nemocnice.Services
{
    public interface INavigationService
    {

        void OpenMainWindow();
        void CloseLoginWindow();
        void OpenLoginWindow();
        void CloseMainWindow();

    }
}
