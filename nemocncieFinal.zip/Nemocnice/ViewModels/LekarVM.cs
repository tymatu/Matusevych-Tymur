﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;
using Nemocnice.Models;
using Nemocnice.Repositories;
using Nemocnice.Util;

namespace Nemocnice.ViewModels;

public class LekarVM : ViewModelBase
{
     public LekarVM(MainVM main,LekarRep lekarRep)
     {
         _lekarRep = lekarRep; 
         _main = main;
         ReloadCommand = new RelayCommand(Reload);
         HledejCommand = new RelayCommand(Hledej);
         AddCommand = new RelayCommand(Add);
         RemoveCommand = new RelayCommand(Remove,CanRemove);
         YourDoubleClickCommand = new RelayCommand(YourDoubleClick);
         Lekari = new ObservableCollection<Lekar>();
         Reload(null);
         IsAdmin = _main.IsAdmin;
     }

     private bool CanRemove(object obj)
     {
         return SelectedLekar != null && SelectedLekar != _main.CurrLekar && SelectedLekar.RoleUser != Role.ADMIN;
     }


     public ICommand ReloadCommand { get; private set; }
        public ICommand HledejCommand { get; private set; }
        public ICommand AddCommand { get; private set; }
        public ICommand RemoveCommand { get; private set; }
        public ICommand YourDoubleClickCommand { get; private set; }

        private ObservableCollection<string> _oddeleniOptions;
        public ObservableCollection<Oddeleni> OddeleniOptions{
            get { return Enum.GetValues(typeof(Oddeleni)).Cast<Oddeleni>().ToObservableCollection(); }
        }

        private Oddeleni _selectedOddeleni;
        
        public Oddeleni SelectedOddeleni
        {
            get { return _selectedOddeleni; }
            set
            {
                if (_selectedOddeleni != value)
                {
                    _selectedOddeleni = value;
                    UpdateFilteredLekari();
                    OnPropertyChanged(nameof(SelectedOddeleni));
                }
            }
        }

        private string _filter;
        public string Filter
        {
            get { return _filter; }
            set
            {
                _filter = value;
                OnPropertyChanged(nameof(Filter));
            }
        }

        private bool _isAdmin;
        public bool IsAdmin
        {
            get { return _isAdmin; }
            set
            {
                _isAdmin = value;
                OnPropertyChanged(nameof(IsAdmin));
            }
        }

        private bool _isMine;
        public bool IsMine
        {
            get { return _isMine; }
            set
            {
                _isMine = value;
                OnPropertyChanged(nameof(IsMine));
            }
        }

        private ObservableCollection<Lekar> _lekari;
        public ObservableCollection<Lekar> Lekari
        {
            get { return _lekari; }
            set
            {
                _lekari = value;
                OnPropertyChanged(nameof(Lekari));
            }
        }

        private Lekar? _selectedLekar;
        private readonly MainVM _main;
        private readonly LekarRep _lekarRep;

        public Lekar? SelectedLekar
        {
            get { return _selectedLekar; }
            set
            {
                _selectedLekar = value;
                OnPropertyChanged(nameof(SelectedLekar));
            }
        }

        private async void UpdateFilteredLekari()
        {
            Lekari.Clear();
            var lekarovy = await _lekarRep.GetAllLekari(SelectedOddeleni);
            foreach (var lekar1 in lekarovy)
            {
                Lekari.Add(lekar1);
            }
        }
        
        private async void Reload(object obj)
        {
            
            Lekari.Clear();
            var lekarovy = await _lekarRep.GetAllLekari();
            foreach (var lekar1 in lekarovy)
            {
                Lekari.Add(lekar1);
            }
        }

        private async void Hledej(object obj)
        {
            Lekari.Clear();
            var lekarovy = await _lekarRep.GetAllLekariByFilter(Filter);
            foreach (var lekar1 in lekarovy)
            {
                Lekari.Add(lekar1);
            }
        }

        private void Add(object obj)
        {
            _main.goToLekProfile(null,_lekarRep);
        }

        private void Remove(object obj)
        {
            _lekarRep.Remove(SelectedLekar);
        }

        private void YourDoubleClick(object obj)
        {
            _main.goToLekProfile(_main.CurrLekar,_lekarRep);
        }

       

       
        
}