﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Nemocnice.Models;
using Nemocnice.Repositories;
using Nemocnice.Util;

namespace Nemocnice.ViewModels;

public class LekarProfileVM : ViewModelBase
{
        private Lekar _currLekar;
        private ObservableCollection<Pacient> pacienty;
        private Oddeleni _selectedOddeleni;
        private readonly MainVM _mainVm;
        private readonly LekarRep _lekarRep;
        private bool _isBelong;
        private string _error;
        private bool _isNew = false;
        private string _password;
        private bool _hide = true;

        public LekarProfileVM(Lekar? lekar,MainVM mainVm,LekarRep lekarRep,bool belong = false)
        {
            
            _lekarRep = lekarRep;
            _mainVm = mainVm;
            Pacienty = new ObservableCollection<Pacient>();

            Ulozit = new RelayCommand(UlozitExecute, CanExecuteUlozit);
            Cancel = new RelayCommand(CancelExecute);
            if (lekar == null)
            {
                CurrLekar = new Lekar();
                CurrLekar.Adresa = new Adresa();
                CurrLekar.Oddeleni = Oddeleni.ALL;
                CurrLekar.UserData = new User();
                IsBelong = true;
                _isNew = true;
                Hide = false;
            }
            else
            {
                CurrLekar = lekar;
                IsBelong = CurrLekar.RoleUser == Role.ADMIN || belong;
                SelectedOddeleni = lekar.Oddeleni;
                var pacc = lekarRep.GetAllPAcientyByLekar(lekar).Result;
                foreach (var pac in pacc)
                {
                    Pacienty.Add(pac);
                }
            }
            
        }

        public Lekar CurrLekar
        {
            get { return _currLekar; }
            set
            {
                if (_currLekar != value)
                {
                    _currLekar = value;
                    OnPropertyChanged(nameof(CurrLekar));
                }
            }
        }
        
        public bool IsBelong
        {
            get { return _isBelong; }
            set
            {
                if (_isBelong != value)
                {
                    _isBelong = value;
                    OnPropertyChanged(nameof(IsBelong));
                }
            }
        }
        public bool Hide
        {
            get { return _hide; }
            set
            {
                if (_hide != value)
                {
                    _hide = value;
                    OnPropertyChanged(nameof(Hide));
                }
            }
        }

        public ObservableCollection<Pacient> Pacienty
        {
            get { return pacienty; }
            set
            {
                if (pacienty != value)
                {
                    pacienty = value;
                    OnPropertyChanged(nameof(Pacienty));
                }
            }
        }
    

        
        public ObservableCollection<Oddeleni> OddeleniOptions{
            get { return Enum.GetValues(typeof(Oddeleni)).Cast<Oddeleni>().ToObservableCollection(); }
        }
        public Oddeleni SelectedOddeleni
        {
            get { return _selectedOddeleni; }
            set
            {
                if (_selectedOddeleni != value)
                {
                    _selectedOddeleni = value;
                    OnPropertyChanged(nameof(SelectedOddeleni));
                }
            }
        }
        public string Password
        {
            get { return _password; }
            set
            {
                if (_password != value)
                {
                    _password = value;
                    OnPropertyChanged(nameof(Password));
                }
            }
        }

        public bool IsNew
        {
            get { return _isNew; }
            set
            {
                if (_isNew != value)
                {
                    _isNew = value;
                    OnPropertyChanged(nameof(IsNew));
                }
            }
        }
        public string Error
        {
            get { return _error; }
            set
            {
                if (_error != value)
                {
                    _error = value;
                    OnPropertyChanged(nameof(Error));
                }
            }
        }

        public ICommand Ulozit { get; }
        public ICommand Cancel { get; }
        

        private bool CanExecuteUlozit(object parameter)
        {
            return true;
        }

        private void UlozitExecute(object parameter)
        {
            try
            {
                CurrLekar.Oddeleni = SelectedOddeleni;
                if (_isNew)
                {
                    CurrLekar.UserData.Password = Password;
                    _lekarRep.Save(CurrLekar);            
                    _mainVm.LekariV(null);
                    return;
                }

                if (!string.IsNullOrWhiteSpace(Password))
                {
                    CurrLekar.UserData.Password = Password;
                }
                _lekarRep.Update(CurrLekar).Wait();
                _mainVm.LekariV(null);
            }
            catch (Exception e)
            {
                Error = "** Vplnite vsechny pole";
                throw;
            }
            
        }
    


        private void CancelExecute(object parameter)
        {
           _mainVm.LekariV(null);
        }

       
}