﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Nemocnice.Models;
using Nemocnice.Repositories;
using Nemocnice.Util;

namespace Nemocnice.ViewModels;

public class PacientyVM : ViewModelBase
{
    private ObservableCollection<Pacient> _pacienty;
    private Oddeleni _selectedOddeleni;
    private readonly PacientRep _pacientRep;
    private string _filter;
    private bool _isMine;
    private readonly MainVM _mainVm;
    private Lekar _currLekar;
    private Pacient? _selectedPac;

    public ObservableCollection<Oddeleni> OddeleniOptions{
        get { return Enum.GetValues(typeof(Oddeleni)).Cast<Oddeleni>().ToObservableCollection(); }
    }
    public RelayCommand ReloadCommand { get; set; }
    public RelayCommand HledejCommand { get; set; }
    public ICommand YourDoubleClickCommand { get; private set; }
    public ICommand RemoveCommand{ get; set; }
    public ICommand AddCommand { get; set; }


    public Oddeleni SelectedOddeleni
    {
        get { return _selectedOddeleni; }
        set
        {
            if (_selectedOddeleni != value)
            {
                _selectedOddeleni = value;
                UpdateFilteredPacients();
                OnPropertyChanged(nameof(SelectedOddeleni));
            }
        }
    }
    public Lekar CurrLekar
    {
        get { return _currLekar; }
        set
        {
            if (_currLekar != value)
            {
                _currLekar = value;
                OnPropertyChanged(nameof(CurrLekar));
            }
        }
    }
    public string Filter
    {
        get { return _filter; }
        set
        {
            if (_filter != value)
            {
                _filter = value;
                UpdateFilteredPacients();
                OnPropertyChanged(nameof(Filter));
            }
        }
    }
    public Pacient? SelectedPac
    {
        get { return _selectedPac; }
        set
        {
            if (_selectedPac != value)
            {
                _selectedPac = value;
                OnPropertyChanged(nameof(SelectedPac));
            }
        }
    }
    
    private async void UpdateFilteredPacients(Lekar lekar = null)
    {
        Pacienty.Clear();
        var pacients = await _pacientRep.getAllPacientsByOddeleni(SelectedOddeleni, lekar);
        foreach (var pacient in pacients)
        {
            Pacienty.Add(pacient);
        }
    }
    public ObservableCollection<Pacient> Pacienty
    {
        get { return _pacienty; }
        set
        {
            _pacienty = value;
            OnPropertyChanged(nameof(Pacienty));
        }
    }

    public PacientyVM(PacientRep pacientRep,MainVM mainVm)
    {
        _mainVm = mainVm;
        _pacientRep = pacientRep;
        CurrLekar = mainVm.CurrLekar;
        ReloadCommand = new RelayCommand(_=>load());
        HledejCommand = new RelayCommand(Find);
        YourDoubleClickCommand = new RelayCommand(AnalyzaDoubleClickExecute);
        RemoveCommand = new RelayCommand(RemoveExecute, CanRemove);
        AddCommand = new RelayCommand(AddExecute);
        load();
    }

    private void AddExecute(object obj)
    {
        _mainVm.goToPacProfile(null,_pacientRep);
    }

    private bool CanRemove(object obj)
    {
        return SelectedPac != null && 
               SelectedPac.Lekar != null && 
               SelectedPac.Lekar.LekarId == _mainVm.CurrLekar.LekarId;
    }

    private void RemoveExecute(object obj)
    {
        _pacientRep.Remove(SelectedPac);
        load();
    }

    public bool IsMine
    {
        get { return _isMine; }
        set
        {
            if (_isMine != value)
            {
                _isMine = value;
                OnPropertyChanged(nameof(IsMine));
                
                if (_isMine)
                {
                    UpdateFilteredPacients(CurrLekar);
                }
                else
                {
                    UpdateFilteredPacients();
                }
            }
        }
    }

    private async void Find(object obj)
    {
        Pacienty.Clear();
        var pacients = await _pacientRep.GetAllPacientsByOddeleniAndFilter(SelectedOddeleni, Filter);
        foreach (var pacient in pacients)
        {
            Pacienty.Add(pacient);
        }
    }
    private bool canFind(object obj)
    {
        return !string.IsNullOrWhiteSpace(Filter);
    }
    private void AnalyzaDoubleClickExecute(object parameter)
    {
        

        if (SelectedPac != null)
        {
            Pacient? p = _pacientRep.GetPacById(SelectedPac.PacientId).Result;
            _mainVm.goToPacProfile(p,_pacientRep);
        }
    }
    private async void load()
    {
        SelectedOddeleni = Oddeleni.ALL;    
        Pacienty = new ObservableCollection<Pacient>();
        var p = await Task.Run(() =>_pacientRep.getAllPacients());
        foreach (var pac in p)
        {
            Pacienty.Add(pac);
        }
    }
}