﻿using System;
using System.Windows.Input;
using Microsoft.Extensions.DependencyInjection;
using Nemocnice.Models;
using Nemocnice.Repositories;
using Nemocnice.Services;
using Nemocnice.Util;
using Nemocnice.Views;

namespace Nemocnice.ViewModels;

public class MainVM : ViewModelBase
{
    private Lekar? _currLekar;
    private bool _logged;
    private object _currentView;
    private readonly IServiceProvider _serviceProvider;
    private bool _isAdmin;

    public void PacientyV(object obj)
    {
        CurrentView = _serviceProvider.GetRequiredService<PacientyView>();
    }
    public void ProfilPac(object obj)
    {
        CurrentView = _serviceProvider.GetRequiredService<PacientProfile>();
    }
    public void DefaultV(object obj)
    {
        CurrentView = _serviceProvider.GetRequiredService<DefaultView>();
    }
    public void LekariV(object obj)
    {
        CurrentView = _serviceProvider.GetRequiredService<LekarView>();
    }

    public RelayCommand PacientyCommand { get; set; }
    public ICommand LekariCommand { get; set; }
    public ICommand OdhlasitCommand{ get; set; }
    public ICommand ProfileCommand{ get; set; }
    public ICommand AnalyzyCommand{ get; set; }
    public object CurrentView
    {
        get { return _currentView; }
        set { _currentView = value; OnPropertyChanged(nameof(CurrentView)); }
    }
    
    public Lekar CurrLekar
    {
        get { return _currLekar; }
        set
        {
            if (_currLekar != value)
            {
                _currLekar = value;
                OnPropertyChanged(nameof(CurrLekar));
            }
        }
    }
    public bool IsAdmin
    {
        get { return _isAdmin; }
        set
        {
            if (_isAdmin != value)
            {
                _isAdmin = value;
                OnPropertyChanged(nameof(IsAdmin));
            }
        }
    }

    public void goToPacProfile(Pacient? pac,PacientRep rep)
    {
        CurrentView = new PacientProfile(new ProfileVM(this,pac,rep));
    }
    public void goToLekProfile(Lekar? lek,LekarRep rep)
    {
        CurrentView = new LekarProfile(new LekarProfileVM(lek,this,rep));
    }
    

    public void LoginSuces(User user)
    {
        CurrLekar = user.Lekar;
        _logged = true;
        IsAdmin = CurrLekar.RoleUser == Role.ADMIN;
    }

    public MainVM(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
        DefaultV(null);
        PacientyCommand = new RelayCommand(PacientyV);
        LekariCommand = new RelayCommand(LekariV);
        OdhlasitCommand = new RelayCommand(OdhlasitEx);
        ProfileCommand = new RelayCommand(Profile);
        AnalyzyCommand = new RelayCommand(AnalyzyEx);
    }

    private void AnalyzyEx(object obj)
    {
        CurrentView = _serviceProvider.GetRequiredService<AnalyzyVIew>();
    }

    private void Profile(object obj)
    {
        CurrentView =
            new LekarProfile(new LekarProfileVM(CurrLekar, this, _serviceProvider.GetRequiredService<LekarRep>(),true));
    }

    private void OdhlasitEx(object obj)
    {
        var service = _serviceProvider.GetRequiredService<INavigationService>();
        service.CloseMainWindow();
    }
}