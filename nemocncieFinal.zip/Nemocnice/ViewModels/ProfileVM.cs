﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Input;
using Nemocnice.Models;
using Nemocnice.Repositories;
using Nemocnice.Util;

namespace Nemocnice.ViewModels;

public class ProfileVM : ViewModelBase
{
     private Pacient _currPacient;
        private bool _isMine;
        private readonly MainVM _mainVm;
        private bool _isBelong;
        private readonly PacientRep _rep;
        private bool _onCreating = false;
        private Oddeleni _selectedOddeleni;
        private string _error;
        private ObservableCollection<Analyza> _analyzy;

        public ObservableCollection<Oddeleni> OddeleniOptions{
            get { return Enum.GetValues(typeof(Oddeleni)).Cast<Oddeleni>().ToObservableCollection(); }
        }
        public Oddeleni SelectedOddeleni
        {
            get { return _selectedOddeleni; }
            set
            {
                if (_selectedOddeleni != value)
                {
                    _selectedOddeleni = value;
                    OnPropertyChanged(nameof(SelectedOddeleni));
                }
            }
        }

        public Pacient CurrPacient
        {
            get { return _currPacient; }
            set
            {
                if (_currPacient != value)
                {
                    _currPacient = value;
                    OnPropertyChanged(nameof(CurrPacient));
                }
            }
        }
        public bool IsBelong
        {
            get { return _isBelong; }
            set
            {
                if (_isBelong != value)
                {
                    _isBelong = value;
                    OnPropertyChanged(nameof(IsBelong));
                }
            }
        }

        public bool IsMine
        {
            get { return _isMine; }
            set
            {
                if (_isMine != value)
                {
                    _isMine = value;
                    OnPropertyChanged(nameof(IsMine));
                }
            }
        }
        public ObservableCollection<Analyza> Analyzy
        {
            get { return _analyzy; }
            set
            {
                if (_analyzy != value)
                {
                    _analyzy = value;
                    OnPropertyChanged(nameof(Analyzy));
                }
            }
        }
        public string Error
        {
            get { return _error; }
            set
            {
                if (_error != value)
                {
                    _error = value;
                    OnPropertyChanged(nameof(Error));
                }
            }
        }

        public ICommand Ulozit { get; private set; }
        public ICommand Cancel { get; private set; }

        public ProfileVM(MainVM mainVm,Pacient? pacient,PacientRep rep)
        {
            _rep = rep;
            _mainVm = mainVm;
            Ulozit = new RelayCommand(UlozitExecute);
            Cancel = new RelayCommand(CancelExecute);
            IsMine = false;
            IsBelong = false;
            Analyzy = new ObservableCollection<Analyza>();
            
            if (pacient == null)
            {
                pacient = new Pacient();
                pacient.Adresa = new Adresa();
                pacient.Card = new HealthCard();
                pacient.Lekar = mainVm.CurrLekar;
                SelectedOddeleni = Oddeleni.ALL;
                _onCreating = true;
            }

            
            CurrPacient = pacient;
            if (CurrPacient.Analyzy != null)
            {
                var an = CurrPacient.Analyzy;
                foreach (var a in an)
                {
                    Analyzy.Add(a);
                }
            }
            
            SelectedOddeleni = CurrPacient.Oddeleni;
            if (pacient.Lekar != null && pacient.Lekar.LekarId == mainVm.CurrLekar.LekarId)
            {
                IsMine = true;
                _isBelong = true;
            }
            if(pacient.Lekar==null) _isBelong = true;
            

        }
      

        
        private void UlozitExecute(object parameter)
        {
            try
            {
                CurrPacient.Oddeleni = SelectedOddeleni;
                if (_onCreating)
                {
                    CurrPacient.Card.DatumPrijeti = DateTime.Now;
                    _rep.Save(CurrPacient);
                    _mainVm.PacientyV(null);
                
                    return;
                }
                if (CurrPacient.Lekar == null)
                {
                    if (IsMine) CurrPacient.Lekar = _mainVm.CurrLekar;
                }
                else
                {
                    if (!IsMine) CurrPacient.Lekar = null;
                }

                _rep.Update(CurrPacient).Wait();
                _mainVm.PacientyV(null);
            }
            catch (Exception e)
            {
                Error = "** Vyplňte všechna pole";
                throw;
            }
            
        }
        

        private void CancelExecute(object parameter)
        {
            _mainVm.PacientyV(null);
        }
        
}