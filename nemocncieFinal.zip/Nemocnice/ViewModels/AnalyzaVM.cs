﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Microsoft.EntityFrameworkCore;
using Nemocnice.Configuration;
using Nemocnice.Models;
using Nemocnice.Util;

namespace Nemocnice.ViewModels;

public class AnalyzaVM : ViewModelBase
{
    private DateTime _datum;
        private string _vysledek;
        private string _filter;
        private ObservableCollection<Analyza> _analyzy;
        private Analyza? _selectedAnalyza;
        private readonly DbConfig _db;
        private Pacient _selectedPacient;


        public AnalyzaVM(DbConfig db)
        {
            _db = db;
            Analyzy = new ObservableCollection<Analyza>();
            ReloadCommand = new RelayCommand(Reload);
            HledejCommand = new RelayCommand(Hledej);
            AddCommand = new RelayCommand(AddAnalyza,CanAddAnalyza);
            RemoveCommand = new RelayCommand(RemoveAnalyza,CanRemove);
            Datum = DateTime.Now;
            var analyz = db.Analyzy.ToList();
            foreach (var a in analyz)
            {
                Analyzy.Add(a);
            }


        }
        public ObservableCollection<Pacient> PacientyOptions
        {
            get { return _db.Pacienti.ToList().ToObservableCollection(); }
        }

        private bool CanRemove(object obj)
        {
            return _selectedAnalyza != null;
        }

        private bool CanAddAnalyza(object obj)
        {
            return !string.IsNullOrWhiteSpace(Vysledek);
        }

        public ICommand ReloadCommand { get; private set; }
        public ICommand HledejCommand { get; private set; }
        public ICommand AddCommand { get; private set; }
        public ICommand RemoveCommand { get; private set; }

        public Analyza? SelectedAnalyza
        {
            get { return _selectedAnalyza; }
            set
            {
                if (_selectedAnalyza != value)
                {
                    _selectedAnalyza = value;
                    OnPropertyChanged(nameof(SelectedAnalyza));
                }
            }
        }
        public DateTime Datum
        {
            get { return _datum; }
            set
            {
                if (_datum != value)
                {
                    _datum = value;
                    OnPropertyChanged(nameof(Datum));
                }
            }
        }

        public string Vysledek
        {
            get { return _vysledek; }
            set
            {
                if (_vysledek != value)
                {
                    _vysledek = value;
                    OnPropertyChanged(nameof(Vysledek));
                }
            }
        }
        public Pacient SelectedPacient
        {
            get { return _selectedPacient; }
            set
            {
                if (_selectedPacient != value)
                {
                    _selectedPacient = value;
                    OnPropertyChanged(nameof(SelectedPacient));
                }
            }
        }
        

        public string Filter
        {
            get { return _filter; }
            set
            {
                if (_filter != value)
                {
                    _filter = value;
                    OnPropertyChanged(nameof(Filter));
                }
            }
        }

        public ObservableCollection<Analyza> Analyzy
        {
            get { return _analyzy; }
            set
            {
                if (_analyzy != value)
                {
                    _analyzy = value;
                    OnPropertyChanged(nameof(Analyzy));
                }
            }
        }

        

       

        private void Reload(object parameter)
        {
            Analyzy.Clear();
            var an = _db.Analyzy.ToList();
            foreach (var a in an)
            {
                Analyzy.Add(a);
            }
        }

        private void Hledej(object parameter)
        {
            Analyzy.Clear();
            var an = _db.Analyzy.ToList();
            an = an.Where(ah => ah.Vysledek.Contains(Filter)).ToList();
            foreach (var a in an)
            {
                Analyzy.Add(a);
            }
        }

        private void AddAnalyza(object parameter)
        {
            Analyza newAnalyza = new Analyza
            {
                DatumAnalyzy = Datum,
                Vysledek = Vysledek,
                Pacient = SelectedPacient
            };

            _db.Analyzy.Add(newAnalyza);

            _db.SaveChanges();

            Reload(null);
            
        }

        private void RemoveAnalyza(object parameter)
        {
            _db.Analyzy.Remove(SelectedAnalyza);
            _db.SaveChanges();
            Reload(null);
        }

}