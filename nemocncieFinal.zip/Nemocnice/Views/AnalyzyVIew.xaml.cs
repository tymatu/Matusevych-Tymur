﻿using System.Windows.Controls;
using Nemocnice.ViewModels;

namespace Nemocnice.Views;

public partial class AnalyzyVIew : UserControl
{
    public AnalyzyVIew(AnalyzaVM analyzaVm)
    {
        InitializeComponent();
        DataContext = analyzaVm;
    }
}