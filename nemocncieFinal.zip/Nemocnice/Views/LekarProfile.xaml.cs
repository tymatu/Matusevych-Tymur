﻿using System.Windows.Controls;
using Nemocnice.ViewModels;

namespace Nemocnice.Views;

public partial class LekarProfile : UserControl
{
    public LekarProfile(LekarProfileVM lek)
    {
        InitializeComponent();
        DataContext = lek;
    }
}