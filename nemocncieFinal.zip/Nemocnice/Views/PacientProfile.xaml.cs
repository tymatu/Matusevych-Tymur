﻿using System.Windows.Controls;
using Nemocnice.Models;
using Nemocnice.ViewModels;

namespace Nemocnice.Views;

public partial class PacientProfile : UserControl
{
    public PacientProfile(ProfileVM profileVm)
    {
        InitializeComponent();
        DataContext = profileVm;
    }
}