﻿using System.Windows.Controls;
using Nemocnice.ViewModels;

namespace Nemocnice.Views;

public partial class LekarView : UserControl
{
    public LekarView(LekarVM lekarVm)
    {
        InitializeComponent();
        DataContext = lekarVm;
    }
}