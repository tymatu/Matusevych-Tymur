﻿using System.Windows.Controls;
using Nemocnice.ViewModels;

namespace Nemocnice.Views;

public partial class PacientyView : UserControl
{
    public PacientyView(PacientyVM pacientyVm)
    {
        InitializeComponent();
        DataContext = pacientyVm;
    }
}