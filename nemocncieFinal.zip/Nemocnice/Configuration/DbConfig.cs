﻿using Microsoft.EntityFrameworkCore;
using Nemocnice.Models;


namespace Nemocnice.Configuration
{
    public class DbConfig : DbContext
    {

        public DbSet<User> Users { get; set; }
        public DbSet<Adresa> Adresy { get; set; }
        public DbSet<Lekar> Lekari { get; set; }
        
        public DbSet<Pacient> Pacienti { get; set; }
        public DbSet<HealthCard> Card { get; set; }
        public DbSet<Analyza> Analyzy { get; set; }
        
        public DbConfig()
        {
            
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            // modelBuilder.Entity<Pacient>()
            //     .HasOne(p => p.Adresa)
            //     .WithOne()
            //     .OnDelete(DeleteBehavior.Cascade);
            //
            // modelBuilder.Entity<Pacient>()
            //     .HasOne(p => p.Lekar)
            //     .WithMany()
            //     .OnDelete(DeleteBehavior.Cascade);
            //
            // modelBuilder.Entity<Pacient>()
            //     .HasOne(p => p.Card)
            //     .WithOne()
            //     .OnDelete(DeleteBehavior.Cascade);
            // modelBuilder.Entity<Lekar>()
            //     .HasMany(l => l.Pacienty)
            //     .WithOne();

            

            base.OnModelCreating(modelBuilder);
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
              optionsBuilder.UseSqlite("Data Source=nemocniceTest23.db");
              optionsBuilder.EnableSensitiveDataLogging();
        }
        public void EnsureDatabaseCreated()
        {
            Database.EnsureCreated();
        }
    }
}
