﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.DependencyInjection;
using Nemocnice.Configuration;
using Nemocnice.Models;
using Nemocnice.Services;
using Nemocnice.ViewModels;
using Nemocnice.Views;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Nemocnice.Repositories;

namespace Nemocnice
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public IServiceProvider? ServiceProvider { get; private set; }
        private void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton<INavigationService, NavigationService>();
            services.AddScoped<PacientRep>();
            services.AddScoped<LekarRep>();
            services.AddTransient<LoginVM>();
            services.AddTransient<LoginView>(provider => new LoginView(provider.GetRequiredService<LoginVM>()));
            services.AddScoped<DbConfig>();
            services.AddTransient<LoginService>();
            services.AddTransient<PacientyVM>();
            services.AddTransient<PacientyView>();
            services.AddSingleton<MainWindow>();
            services.AddSingleton<DefaultView>();
            services.AddSingleton<MainVM>();
            services.AddTransient<LekarView>();
            services.AddTransient<LekarVM>();
            services.AddTransient<AnalyzyVIew>();
            services.AddTransient<AnalyzaVM>();
            // services.AddTransient<LekarProfile>();
            // services.AddTransient<LekarProfileVM>();
            // services.AddTransient<PacientProfile>();
            // services.AddTransient<ProfileVM>();


        }
        private void Start(object sender, StartupEventArgs e)
        {
            var serviceCollection = new ServiceCollection();
            ConfigureServices(serviceCollection);
            ServiceProvider = serviceCollection.BuildServiceProvider();
            DbConfig config = ServiceProvider.GetRequiredService<DbConfig>(); 
            Initialize(config); //Activate to reload database
            var mainWindow = ServiceProvider.GetRequiredService<MainWindow>();
            Application.Current.MainWindow = mainWindow;


            var navigationMenu = ServiceProvider.GetRequiredService<INavigationService>();
            navigationMenu.OpenLoginWindow();
            

        }
        public static void Initialize(DbConfig context)
        {
            context.Database.EnsureDeleted();
            context.EnsureDatabaseCreated();
            
                Adresa adresa1 = new Adresa
                {
                    Ulice = "Main Street",
                    Mesto = "Cityville",
                    PSC = "12345",
                    CP = "sds",
                    CO = ""
                };
                Adresa adresaAdmin = new Adresa
                {
                    Ulice = "Main Street",
                    Mesto = "Cityville",
                    PSC = "12345",
                    CP = "sds",
                    CO = ""
                };
                

                Adresa adresa2 = new Adresa
                {
                    Ulice = "Oak Avenue",
                    Mesto = "Townsville",
                    PSC = "54321",
                    CP = "sds",
                    CO = ""
                };
                HealthCard healthCard1 = new HealthCard
            {
                DatumPrijeti = DateTime.Now,
                Diagnoza = "Some Diagnosis 1",
                Symptomy = "Some Symptoms 1",
                Zaloby = "Some Complaints 1",
                Zaver = "Some Conclusion 1",
            };

            HealthCard healthCard2 = new HealthCard
            {
                DatumPrijeti = DateTime.Now.AddDays(-7),
                Diagnoza = "Some Diagnosis 2",
                Symptomy = "Some Symptoms 2",
                Zaloby = "Some Complaints 2",
                Zaver = "Some Conclusion 2",
                
            };

            HealthCard healthCard3 = new HealthCard
            {
                DatumPrijeti = DateTime.Now.AddDays(-14),
                Diagnoza = "Some Diagnosis 3",
                Symptomy = "Some Symptoms 3",
                Zaloby = "Some Complaints 3",
                Zaver = "Some Conclusion 3",
                
            };
   
             Lekar lekar1 = new Lekar
             {
                 Jmeno = "John",
                 Prijmeni = "Doe",
                 Oddeleni = Oddeleni.Chirurgie,
                 TelCislo = "123456789",
                 Adresa = adresa1,
                 RoleUser = Role.LEKAR
             };

            Lekar lekar2 = new Lekar
            {
                Jmeno = "Jane",
                Prijmeni = "Smith",
                Oddeleni = Oddeleni.Pediatrie,
                TelCislo = "987654321",
                Adresa = adresa2,
                RoleUser = Role.LEKAR
            };
            Lekar lekar3 = new Lekar
            {
                Jmeno = "ADMIN",
                Prijmeni = "ADMIN",
                Oddeleni = Oddeleni.ALL,
                TelCislo = "888888888",
                Adresa = adresaAdmin,
                RoleUser = Role.ADMIN,
                UserData = new User { UserName = "admin", Password = "admin"}
            };

            User user1 = new User
            {
                UserName = "john_doe",
                Password = "password123",
                Lekar = lekar1,
            };

            User user2 = new User
            {
                UserName = "jane_smith",
                Password = "securepass",
                Lekar = lekar2,
            };
            Adresa adresa3 = new Adresa
            {
                Ulice = "Hlavni",
                Mesto = "Praha",
                PSC = "12345"
            };

            Adresa adresa4 = new Adresa
            {
                Ulice = "Namesti",
                Mesto = "Brno",
                PSC = "54321",
                CP = "12"
            };

            Adresa adresa5 = new Adresa
            {
                Ulice = "Ceska",
                Mesto = "Ostrava",
                PSC = "98765",
                CP = "7",
                CO = "2"
            };

            Pacient pacient1 = new Pacient
            {
                Jmeno = "Jan",
                Prijmeni = "Novak",
                CisloPojisteni = "123456789",
                TelCislo = "123456789",
                Oddeleni = Oddeleni.Interni,
                Card = healthCard1,
                Adresa = adresa1,
               
            };

            Analyza analyza = new Analyza { DatumAnalyzy = DateTime.Today, Vysledek = "COVID", Pacient = pacient1 };
            Pacient pacient2 = new Pacient
            {
                Jmeno = "Eva",
                Prijmeni = "Svobodova",
                CisloPojisteni = "987654321",
                TelCislo = "987654321",
                Oddeleni = Oddeleni.Pediatrie,
                Card = healthCard2,
                Adresa = adresa2  
            };

            Pacient pacient3 = new Pacient
            {
                Jmeno = "Petr",
                Prijmeni = "Kolar",
                CisloPojisteni = "555555555",
                TelCislo = "555555555",
                Oddeleni = Oddeleni.Chirurgie,
                Card = healthCard3,
                Adresa = adresa3
            };
            lekar1.UserData = user1;
            lekar2.UserData = user2;
            lekar1.Pacienty.Add(pacient2);
            context.Pacienti.AddRange(pacient1,pacient2,pacient3);
            context.Lekari.AddRange(lekar1, lekar2,lekar3);
            context.Card.AddRange(healthCard1,healthCard2,healthCard3);
            context.Users.AddRange(user1, user2);
            context.Adresy.AddRange(adresa1,adresa2,adresa3,adresa4,adresa5,adresaAdmin);
            context.Add(analyza);
            
            context.SaveChanges();
        }
    }
}
