[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/YGUPAXi8)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-7f7980b617ed060a017424585567c406b6ee15c891e84e1186181d67ecf80aa0.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=13248936)
# Exercise 11 - ASP.NET Core - Minimal APIs

* Seznamte se s moderními architektonickými přístupy k tvorbě rozsáhlých (webových) aplikací - [Architecture styles](https://learn.microsoft.com/en-us/azure/architecture/guide/architecture-styles/)
  * Přečtěte si základní charakteristiky mikroslužbového přístupu - [Microservice architecture style](https://learn.microsoft.com/en-us/azure/architecture/guide/architecture-styles/microservices)
* Vytvořte jednoduchou webovou API aplikaci - [Tutorial: Create a minimal web API with ASP.NET Core](https://learn.microsoft.com/en-us/aspnet/core/tutorials/min-web-api?view=aspnetcore-7.0&tabs=visual-studio)
* [volitelné] Projděte si další zdroje a informace o mikroslužbách a .NET ekosystému - [.NET Microservices Architecture Guidance](https://dotnet.microsoft.com/en-us/learn/aspnet/microservices-architecture)
* [volitelné] Projděte si architekturu a zdrojové kódy ukázkové mikroslužbové aplikace - [dotnet/eShop](https://github.com/dotnet/eShop)